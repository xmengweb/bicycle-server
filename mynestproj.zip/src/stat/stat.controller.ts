import { Controller } from '@nestjs/common';

@Controller('stat')
export class StatController {}
