export interface UserQeury {
  page: number;
  limit?: number;
  username?: string;
  email?: string;
}
