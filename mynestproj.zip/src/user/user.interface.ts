export interface IUserData {
  username: string;
  email: string;
  password: string;
  created_at: string;
  updated_at: string;
}
